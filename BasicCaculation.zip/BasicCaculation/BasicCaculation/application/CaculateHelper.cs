﻿using System;

namespace BasicCaculation.application
{
    public static class CaculateHelper
    {
        public static double XuLyBieuThuc(string bieuthuc)
        {
            MyStack toanhang = new MyStack(); // Ngăn xếp số
            MyStack toantu = new MyStack();    // Ngăn xếp toán tử

            // Thay thế các ký tự toán học đặc biệt bằng ký tự dễ xử lý
            bieuthuc = bieuthuc.Replace("÷", "/").Replace("×", "*");
            int i = 0;
            while (i < bieuthuc.Length) // duyệt qua từng ký tự của biểu thức 12*(4+4)/5 -> 1 2 * ( 4 + 4 ) / 5
            {
                char current = bieuthuc[i]; // chuyển biểu thức về mảng chuỗi 

                // Bỏ qua khoảng trắng 
                if (current == ' ')
                {
                    i++;
                    continue;
                }
                // i = 0 -> current = 1  -> lưu vào number -> tăng i
                // i = 1 -> current = 2 -> lưu vào number -> tăng 1 
                // i = 2 -> curent = * -> 

                // Nếu là số, đọc toàn bộ số và đẩy vào ngăn xếp
                if (char.IsDigit(current) || current == '.') // dấu thập phân 
                {
                    string number = ""; // lưu toán hạng 
                    while (i < bieuthuc.Length && (char.IsDigit(bieuthuc[i]) || bieuthuc[i] == '.'))
                    {
                        number += bieuthuc[i];
                        i++;
                    }
                    toanhang.Push(double.Parse(number));
                    continue;
                }

                // Nếu là dấu mở ngoặc, đẩy vào ngăn xếp
                if (current == '(')
                {
                    toantu.Push(current);
                }
                // Nếu là dấu đóng ngoặc, tính toán bên trong ngoặc
                else if (current == ')')
                {
                    while ((char)toantu.Peek() != '(')
                    {
                        TinhBieuThuc(toanhang, toantu);
                    }
                    toantu.Pop(); // Bỏ dấu '(' khỏi stack
                }
                // Nếu là toán tử
                else if (IsOperator(current))
                {
                    // Xử lý ưu tiên toán tử
                    while (!toantu.IsEmpty() && Priority((char)toantu.Peek()) >= Priority(current))
                    {
                        TinhBieuThuc(toanhang, toantu);
                    }
                    toantu.Push(current);
                }

                i++;
            }

            // Xử lý các toán tử còn lại
            while (!toantu.IsEmpty())
            {
                TinhBieuThuc(toanhang, toantu);
            }

            return (double)toanhang.Pop().data;
        }
        private static void TinhBieuThuc(MyStack toanhang, MyStack toantu)
        {
            char op = (char)toantu.Pop().data;

            // // Xử lý toán tử đơn ngôi (√)
            // if (op == 's') // √
            // {
            //     double operand = toanhang.Pop();
            //     toanhang.Push(Math.Sqrt(operand));
            // }
            // else
            // {
            double toanhang2 = (double)toanhang.Pop().data;
            double toanhang1 = (double)toanhang.Pop().data;

            switch (op)
            {
                case '+': toanhang.Push(toanhang2 + toanhang1); break;
                case '-': toanhang.Push(toanhang1 - toanhang2); break;
                case '*': toanhang.Push(toanhang1 * toanhang2); break;
                case '/': toanhang.Push(toanhang1 / toanhang2); break;
            }
            //}
        }
        private static bool IsOperator(char c)
        {
            return c == '+' || c == '-' || c == '*' || c == '/';
        }
        private static int Priority(char op)
        {
            switch (op)
            {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                default: return 0;
            }
        }
    }
}